from cjfx import sqlite_connection, pandas


db = sqlite_connection('./QSWATPlusProj.sqlite')
db.connect()

data = pandas.read_csv('./plant.csv')

data.to_sql('plant', db.connection, if_exists='replace', index=False)
data.to_sql('plant_plt', db.connection, if_exists='replace', index=False)

db.close_connection()

