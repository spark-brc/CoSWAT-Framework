#include "linearpart.h"


//int catchoutlets(char *pfile, char *streamnetsrc, char *streamnetlyr, char *outletsdatasrc, char *outletslayer, int  lyrno, float maxdist);
int catchoutlets(char *pfile, char *streamnetsrc,char *outletsdatasrc, double mindist, int gwstartno, double minarea);
//  Incomplete implementation no capability for layers within data sources yet
