
int flood( char* demfile, char* felfile, char *fdrfile, int usefdr,bool verbose, 
           bool is_4Point,bool use_mask,char *maskfile);
