#include "linearpart.h"

int connectdown(char *pfile, char *wfile, char *ad8file, char *outletdatasrc, char *outletlyr,char *movedoutletdatasrc,char *movedoutletlyr, int movedist);
